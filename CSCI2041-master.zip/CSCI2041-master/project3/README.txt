An interpreter that manually creates a list in a functional programming language 
(OCaml) to represent how lists are created and maintained in Lisp. A REPL (read-evaluate-print-loop) 
is used in which characters are scanned to create tokens, which are meaningful chunks of characters. 
These tokens are then parsed to output the desired data structure (list in this case).
Comments clarify the functions used within the REPL which is the function named lisp.
